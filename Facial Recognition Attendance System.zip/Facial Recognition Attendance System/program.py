import face_recognition
import cv2
import numpy as np
import csv
import os
from datetime import datetime

# Attempting to use camera index 0 (adjust if needed)
video_capture = cv2.VideoCapture(0)

# Define image paths for recognition (make sure these paths are correct)
image_paths = {
    "Elon Musk": "photos/Elon Musk.jpg",
    "Jeff Bezos": "photos/Jeff Bezos.jpg",
    "Mark Zuckerberg": "photos/Mark Zuckerberg.jpg",
    "Ratan Tata": "photos/Ratan Tata.jpg",
    "Umar": "photos/Umar.jpg"
}

# Initialize encodings list
known_face_encoding = []
known_face_names = []

# Load images and generate encodings
for name, image_path in image_paths.items():
    try:
        image = face_recognition.load_image_file(image_path)
        encoding = face_recognition.face_encodings(image)[0]
        known_face_encoding.append(encoding)
        known_face_names.append(name)
    except FileNotFoundError:
        print(f"Error: Image file for {name} not found at {image_path}")
        continue

# List of students for attendance tracking
students = known_face_names.copy()

# Open CSV file for writing attendance data
now = datetime.now()
current_date = now.strftime("Time_" + "%H-%M-%S" + " , " + "Date_" + "%Y-%m-%d")
f = open(current_date + '.csv', 'w+', newline='')
lnwriter = csv.writer(f)

# Main loop for video capture and facial recognition
while True:
    _, frame = video_capture.read()

    # Resize frame for faster processing
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
    rgb_small_frame = small_frame[:, :, ::-1]

    # Detect faces and encode them
    face_locations = face_recognition.face_locations(rgb_small_frame)
    face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
    face_names = []

    # Check each face encoding against known faces
    for face_encoding in face_encodings:
        matches = face_recognition.compare_faces(known_face_encoding, face_encoding)
        name = ""
        face_distance = face_recognition.face_distance(known_face_encoding, face_encoding)
        best_match_index = np.argmin(face_distance)

        if matches[best_match_index]:
            name = known_face_names[best_match_index]

        face_names.append(name)

        # Record attendance if a recognized student is detected
        if name in known_face_names:
            if name in students:
                students.remove(name)
                print(students)
                current_time = now.strftime('%H:%M:%S')
                lnwriter.writerow([name, current_time])

    # Display the video feed with face recognition
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
        cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2, cv2.LINE_AA)

    # Show the video frame with labels
    cv2.imshow("Facial Recognition Attendance System", frame)

    # Exit on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture and close the window
video_capture.release()
cv2.destroyAllWindows()
f.close()
